
function registerUser(event) {
    event.preventDefault(); 

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    const confirmationMessage = document.getElementById("confirmationMessage");

    if (!localStorage.getItem(email)) {
        localStorage.setItem(email, JSON.stringify({ name, password, role }));
        confirmationMessage.style.display = "block";
        confirmationMessage.textContent = `Welcome to WETS, ${name}! You have registered as a ${role}.`;
        document.getElementById("registerForm").reset(); 
    } else {
        confirmationMessage.style.display = "block";
        confirmationMessage.textContent = "This email is already registered. Please log in.";
    }
}

 
function loginUser(event) {
    event.preventDefault(); 

  
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const validCredentials = {
        email: "trainee@example.com",
        password: "12345",
        role: "Trainee"
    };

    
    if (email === validCredentials.email && password === validCredentials.password && validCredentials.role === "Trainee") {
       
        alert("Login successful!");
        window.location.href = "Training program/Training.html";
    } else {
       
        const loginMessage = document.getElementById("loginMessage");
        loginMessage.style.display = "block";
        loginMessage.textContent = "Invalid email or password. Please try again.";
    }
}


function loginUser(event) {
    event.preventDefault();

    const email = document.querySelector(".login-email").value;
    const password = document.querySelector(".login-password").value;

    const validEmployer = { email: "employer@example.com", password: "password" };

    if (email === validEmployer.email && password === validEmployer.password) {
        alert("Login successful! Redirecting to Employer Dashboard...");
        window.location.href = "employer-dashboard.html";
    } else {
        alert("Invalid login credentials. Please try again.");
    }
}


function toggleSidebar() {
    const sidebar = document.querySelector(".sidebar");
    sidebar.style.display = sidebar.style.display === "none" ? "block" : "none";
}


window.onclick = function(event) {
    const sidebar = document.querySelector(".sidebar");
    if (event.target === sidebar) {
        sidebar.style.display = "none";
    }
};

let currentSlide = 0;

function showSlides() {
    const slides = document.querySelectorAll('.slide');
    slides.forEach(slide => (slide.style.display = 'none'));
    currentSlide++;
    if (currentSlide > slides.length) currentSlide = 1;
    slides[currentSlide - 1].style.display = 'block';
    setTimeout(showSlides, 3000); 
}


showSlides();
