
function registerUser(event) {
    event.preventDefault(); 

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;

    const confirmationMessage = document.getElementById("confirmationMessage");

    if (!localStorage.getItem(email)) {
        localStorage.setItem(email, JSON.stringify({ name, password, role }));
        confirmationMessage.style.display = "block";
        confirmationMessage.textContent = `Welcome to WETS, ${name}! You have registered as a ${role}.`;
        document.getElementById("registerForm").reset(); 
    } else {
        confirmationMessage.style.display = "block";
        confirmationMessage.textContent = "This email is already registered. Please log in.";
    }
}


function loginUser(event) {
    event.preventDefault(); 

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const user = JSON.parse(localStorage.getItem(email));

    const loginMessage = document.getElementById("loginMessage");

    if (user && user.password === password) {
        loginMessage.style.display = "block";
        loginMessage.textContent = `Welcome back, ${user.name}! Redirecting to your ${user.role} dashboard...`;
        setTimeout(() => {
            window.location.href = `${user.role.toLowerCase()}-dashboard.html`;
        }, 2000);
    } else {
        loginMessage.style.display = "block";
        loginMessage.textContent = "Invalid email or password. Please try again.";
    }
}
