let enrolledCourses = [];
function toggleEnrollment(button, courseName) {
    if (!enrolledCourses.includes(courseName)) {
       
        enrolledCourses.push(courseName);
        button.textContent = "Unenroll";
        updateProgress();
    } else {
        
        enrolledCourses = enrolledCourses.filter(course => course !== courseName);
        button.textContent = "Enroll";
        updateProgress();
    }
}

function updateProgress() {
    const progressMessage = document.querySelector(".progress-message");

   
    if (enrolledCourses.length > 0) {
        progressMessage.textContent = `You have enrolled in ${enrolledCourses.length} course(s): ${enrolledCourses.join(", ")}.`;
    } else {
        progressMessage.textContent = "You have not enrolled in any courses yet.";
    }

    
    const jobListingsButton = document.querySelector(".job-listings-button");
    if (enrolledCourses.length === 8) {
        jobListingsButton.disabled = false;
        jobListingsButton.textContent = "View Job Listings";
    } else {
        jobListingsButton.disabled = true;
        jobListingsButton.textContent = "Check Job Listings";
    }
}

function checkJobListings() {
    alert("Redirecting to job listings...");
    
    window.location.href = "job/jobs.html";
}

function connectWithTrainer(courseName) {
    alert(`Connecting with the trainer for ${courseName}...`);
    
    window.location.href = `connect-with-trainer.html?course=${encodeURIComponent(courseName)}`;
}
