function submitApplication(event) {
    event.preventDefault();  // Prevent the form from submitting normally

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const coverLetter = document.getElementById("coverLetter").value;
    const resume = document.getElementById("resume").files[0];

    if (name && email && coverLetter && resume) {
        // Show confirmation message
        document.getElementById("confirmationMessage").style.display = "block";
        document.getElementById("confirmationMessage").textContent = "Thank you, " + name + "! Your application has been submitted.";
        
        // Clear the form fields
        document.getElementById("jobApplicationForm").reset();
    } else {
        alert("Please fill out all fields and upload your resume.");
    }
}
